# 宇智行 · 个人网站

「宇智行」个人品牌网站前端实现。单页多区块（Hero / 关于作者 / 文章 / 服务理念 / 页脚），
React + TypeScript + Vite，深色优先（品牌色）+ 浅色模式，桌面 / 移动响应式。

- 设计基准：UI 设计 v2.0 定稿（`index.html` 页面稿 / `design-spec.md` / `interaction-plan.md`，见设计议题 YUZHIXING-4）
- 需求基准：PRD v1.1（产品议题 YUZHIXING-3），验收标准 AC-1 ~ AC-19
- 线上地址：https://<project>.vercel.app（部署后更新）

## 开发

```bash
npm install
npm run dev          # 本地开发
npm run build        # 生产构建（tsc + vite，输出 dist/）
npm run preview      # 本地预览生产构建
```

## 自测

```bash
node scripts/optimize-images.mjs   # 图片压缩（logo / 二维码 → WebP + 兜底，≤60KB）
npm run preview -- --port 4173     # 先启动预览服务
node scripts/verify.mjs            # 验收自测（PRD AC 项 + 桌面/移动截图，输出 verify-out/）
node scripts/stylecheck.mjs        # 设计令牌样式抽检
```

`verify.mjs` 使用本机已安装的 Chromium（自动探测 `%LOCALAPPDATA%\ms-playwright`），
无需 `npx playwright install`。

## 结构

```
src/
  components/   Header / Hero / About / Articles / Philosophy / Footer / Logo / Reveal
  data/         articles.json（24 篇文章集中配置，PRD 附录 A）
  styles/       global.css（design-spec v2.0 设计令牌 + 全站样式）
  App.tsx       交互逻辑集中于此（开场/滚动揭示/视差/导航/聚光灯/磁吸/主题）
public/         logo.webp / logo.png / weixin-qr.webp / weixin-qr.jpg / favicon.png
scripts/        optimize-images.mjs / verify.mjs / stylecheck.mjs
```

## 文章数据维护（只改配置，不改组件）

`src/data/articles.json` 字段：

| 字段 | 说明 |
| --- | --- |
| `title` | 文章标题（逐字取自主议题清单） |
| `link` | 公众号原文链接 |
| `category` | 四分类之一：场景认知 / 落地方法论 / 商业成果 / 个人实践 |
| `featured` | `true` = 精选 8 篇（顺序即展示顺序）；`false` = 「查看全部」区 |

「查看全部」区按 `CATEGORY_ORDER`（`Articles.tsx`）分组渲染，组内保持数组顺序。

## 验收要点对照

- 精选 8 篇 →「查看全部 24 篇」页内展开其余 16 篇（四分类分组紧凑列表）→「收起」/「收起全部」；
  刷新后回到默认折叠态；`aria-expanded` 状态完整；动效尊重 `prefers-reduced-motion`
- 24 条外链全部 `target="_blank" rel="noopener"`，点击新窗口打开公众号原文
- Logo 全站正圆（导航 32 / 抽屉 40 / Hero 56 / 页脚 36），`border-radius:50%` + 居中裁切
- 页脚底部左侧公众号二维码：96px（移动 80px）、圆角 8px、WebP ≤60KB + JPG 兜底、
  `alt="关注宇智行公众号二维码"`、引导文案「关注「宇智行」公众号」
- 图片全部 ≤60KB（logo.webp 14KB / logo.png 兜底 44.6KB / weixin-qr.webp 11KB / weixin-qr.jpg 29.5KB）
- 交互（interaction-plan v2.0）：开场动画（会话内一次 + 1s 超时兜底）、滚动揭示
  （CSS scroll-driven 优先 + IO 兜底）、Hero 视差（仅桌面）、导航毛玻璃 / 滚动隐藏 / scrollspy、
  滚动进度条、卡片聚光灯 + CTA 磁吸（仅 hover 指针设备）、主题切换（防闪白 + localStorage + 系统跟随）
- 无 JS 时内容仍完整可见（动效为增强层）

## 部署（Vercel）

- 构建命令 `npm run build`，输出目录 `dist`
- 通过 Vercel CLI：`npx vercel --prod`（需要 `VERCEL_TOKEN` 或交互登录）
- 或连接 GitHub 仓库走 Vercel Git 集成（推荐，推送即部署）
