/**
 * 验收自测脚本（PRD v1.1 §5 验收标准）
 * 覆盖：AC-1~AC-19 中前端可自测项 + 桌面/移动截图
 * 用法：先启动服务（npm run preview -- --port 4173），再 node scripts/verify.mjs
 */
import { chromium } from 'playwright';
import { mkdirSync, readdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir } from 'node:os';

const outDir = join(dirname(fileURLToPath(import.meta.url)), '..', 'verify-out');
mkdirSync(outDir, { recursive: true });

const BASE = process.env.BASE_URL ?? 'http://localhost:4173';

const results = [];
const ok = (name, pass, detail = '') => {
  results.push({ name, pass, detail });
  console.log(`${pass ? 'PASS' : 'FAIL'}  ${name}${detail ? ` — ${detail}` : ''}`);
};

/** 使用本机已安装的 Chromium（版本号与 playwright 期望不一致时兜底） */
function findChrome() {
  const candidates = [];
  if (process.env.PLAYWRIGHT_CHROMIUM_EXE) candidates.push(process.env.PLAYWRIGHT_CHROMIUM_EXE);
  const root = join(homedir(), 'AppData', 'Local', 'ms-playwright');
  if (existsSync(root)) {
    const dirs = readdirSync(root).filter((d) => d.startsWith('chromium-')).sort().reverse();
    for (const d of dirs) {
      candidates.push(join(root, d, 'chrome-win64', 'chrome.exe'));
    }
  }
  for (const c of candidates) {
    if (existsSync(c)) return c;
  }
  return null;
}

const browser = await chromium.launch({ executablePath: findChrome() });

/* ---------------- 桌面 1440 ---------------- */
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const consoleErrors = [];
page.on('console', (m) => {
  if (m.type() === 'error') consoleErrors.push(m.text());
});
page.on('pageerror', (e) => consoleErrors.push(String(e)));

await page.goto(BASE, { waitUntil: 'networkidle' });
await page.waitForTimeout(1200);

// AC-1 Hero
ok('AC-1 Hero 主标题', (await page.locator('.hero h1').innerText()).replace(/\s/g, '') === '智行合一数创未来');
ok('AC-1 品牌语', await page.locator('.hero-kicker').isVisible());
ok('AC-1 副标题 + 两个 CTA', (await page.locator('.hero-ctas a').count()) === 2);

// AC-2 三支柱 + 引用块
ok('AC-2 三支柱卡片', (await page.locator('.about-pillars .pillar-card').count()) === 3);
const pillarText = await page.locator('.about-pillars').innerText();
ok('AC-2 支柱文案（品牌原文）', pillarText.includes('企业级 AI 产品从 0 到 1') && pillarText.includes('西安交通大学 MBA · 战略管理') && pillarText.includes('38 万字深度内容，6 篇行业方法论文章'));
const quoteText = await page.locator('.quote-panel blockquote').innerText();
ok('AC-2 完整版定位引用块', quoteText.includes('宇智行，AI 产品变革探索者') && quoteText.includes('找对场景') && quoteText.includes('商业成果转化'));

// AC-3 文章区块：精选 8 篇 + 副文案
ok('AC-3 副文案', (await page.locator('#articles .section-head .lead').innerText()).includes('38 万字深度内容沉淀 · 24 篇文章'));
const cardCount = await page.locator('#articles-grid .card').count();
ok('AC-3 默认精选 8 篇', cardCount === 8, `实际 ${cardCount}`);
const chip1 = await page.locator('#articles-grid .card').first().locator('.chip').innerText();
ok('AC-3 分类标签（首卡=场景认知）', chip1 === '场景认知', chip1);
const card1Title = await page.locator('#articles-grid .card').first().locator('h3').innerText();
ok('AC-3 精选顺序（首篇标题）', card1Title.includes('黄仁勋说AI能赚钱了'), card1Title.slice(0, 20));

// AC-7 Logo 圆形
const logoRadius = await page.locator('#site-header .brand img').evaluate((el) => getComputedStyle(el).borderRadius);
ok('AC-7 导航 Logo 正圆', logoRadius === '50%', `border-radius=${logoRadius}`);
const logoCount = await page.locator('img.logo-round').count();
ok('AC-7 全站 Logo 圆形类', logoCount >= 4, `${logoCount} 处`);

// AC-9 查看全部展开
const toggle = page.locator('#articles-toggle');
ok('AC-9 入口按钮可见', await toggle.isVisible());
ok('AC-9 aria-expanded=false', (await toggle.getAttribute('aria-expanded')) === 'false');
await toggle.click();
await page.waitForTimeout(900);
const extraVisible = await page.locator('#articles-extra').isVisible();
const groupCount = await page.locator('#articles-extra .extra-group').count();
const extraItems = await page.locator('#articles-extra .extra-item').count();
ok('AC-9 展开 16 篇（4 分组）', extraVisible && groupCount === 4 && extraItems === 16, `分组 ${groupCount}，条目 ${extraItems}`);
ok('AC-9 按钮态切换「收起」', (await page.locator('#articles-toggle .toggle-label').innerText()) === '收起');
ok('AC-9 aria-expanded=true', (await toggle.getAttribute('aria-expanded')) === 'true');
const groupTitles = await page.locator('#articles-extra .group-title').allInnerTexts();
ok('AC-9 四分类小标题', JSON.stringify(groupTitles) === JSON.stringify(['场景认知', '落地方法论', '商业成果', '个人实践']), groupTitles.join('/'));
await page.locator('#articles-extra').scrollIntoViewIfNeeded();
await page.screenshot({ path: join(outDir, 'desktop-articles-expanded.png'), fullPage: false });

// AC-10 收起
await page.locator('#articles-collapse-mini').click();
await page.waitForTimeout(300);
ok('AC-10 收起后隐藏', !(await page.locator('#articles-extra').isVisible()));

// AC-8 外链：24 条 target=_blank + rel=noopener
const featuredLinks = await page.locator('#articles-grid .card').count();
await toggle.click();
await page.waitForTimeout(200);
const allLinks = await page.locator('a[href^="https://mp.weixin.qq.com"]').count();
let linkOk = featuredLinks === 8 && allLinks === 24;
for (const a of await page.locator('a[href^="https://mp.weixin.qq.com"]').all()) {
  if ((await a.getAttribute('target')) !== '_blank') linkOk = false;
  if ((await a.getAttribute('rel')) !== 'noopener') linkOk = false;
}
ok('AC-8 24 条外链新窗口 + noopener', linkOk, `${allLinks} 条`);
await page.locator('#articles-toggle').click();
await page.waitForTimeout(200);

// AC-11/12 锚点与 scrollspy（先回顶，让固定导航可见）
await page.evaluate(() => window.scrollTo(0, 0));
await page.waitForTimeout(500);
await page.locator('.main-nav a[href="#articles"]').click();
await page.waitForTimeout(900);
ok('AC-11 锚点平滑滚动', Math.abs(await page.evaluate(() => document.getElementById('articles').getBoundingClientRect().top)) < 200);
ok('AC-12 scrollspy 高亮', (await page.locator('.main-nav a.active').getAttribute('href')) === '#articles');

// 页脚二维码
const qr = page.locator('.footer-qr img');
ok('页脚二维码存在', (await qr.count()) === 1);
ok('二维码 alt', (await qr.getAttribute('alt')) === '关注宇智行公众号二维码');
ok('二维码 96px', (await qr.evaluate((el) => el.getBoundingClientRect().width)) === 96);
ok('二维码圆角 8px', (await qr.evaluate((el) => getComputedStyle(el).borderRadius)) === '8px');
const qrCaption = await page.locator('.footer-qr figcaption').innerText();
ok('二维码引导文案', qrCaption.includes('关注「宇智行」公众号'), qrCaption);
const qrLeftAligned = await page.evaluate(() => {
  const qr = document.querySelector('.footer-qr').getBoundingClientRect();
  const footer = document.querySelector('.footer-bottom').getBoundingClientRect();
  return qr.left === footer.left;
});
ok('二维码位于页脚底部左侧', qrLeftAligned);

// AC-15 无横向滚动
const noHScroll = await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
ok('AC-15 桌面无横向滚动', noHScroll);

// AC-19 语义化
ok('AC-19 语义化标签', (await page.locator('header, main, footer, nav').count()) >= 4);

// 主题切换（先回顶，让固定导航可见；无头浏览器系统偏好为 light，验证“切换后取反”）
await page.evaluate(() => window.scrollTo(0, 0));
await page.waitForTimeout(500);
const themeBefore = await page.getAttribute('html', 'data-theme');
await page.locator('#theme-toggle').click();
await page.waitForTimeout(600);
const themeAfter = await page.getAttribute('html', 'data-theme');
ok('P1-6 主题切换生效', themeBefore !== themeAfter, `${themeBefore} → ${themeAfter}`);
const themePersisted = await page.evaluate(() => localStorage.getItem('yx-theme'));
ok('P1-6 主题写入 localStorage', themePersisted === themeAfter, themePersisted ?? 'null');
// 恢复初始主题
if (themeAfter !== themeBefore) {
  await page.locator('#theme-toggle').click();
  await page.waitForTimeout(600);
}

// 控制台错误
ok('AC-18 无控制台报错', consoleErrors.length === 0, consoleErrors.slice(0, 3).join(' | '));

// 全页截图
await page.screenshot({ path: join(outDir, 'desktop-full.png'), fullPage: true });
await page.evaluate(() => window.scrollTo(0, 0));
await page.waitForTimeout(500);
await page.screenshot({ path: join(outDir, 'desktop-hero.png') });
await page.close();

/* ---------------- 移动 390x844 ---------------- */
const mobile = await browser.newPage({ viewport: { width: 390, height: 844 } });
const mErrors = [];
mobile.on('console', (m) => {
  if (m.type() === 'error') mErrors.push(m.text());
});
mobile.on('pageerror', (e) => mErrors.push(String(e)));
await mobile.goto(BASE, { waitUntil: 'networkidle' });
await mobile.waitForTimeout(1200);

ok('移动端汉堡按钮可见', await mobile.locator('#menu-btn').isVisible());
ok('移动端导航折叠', !(await mobile.locator('.main-nav').isVisible()));

await mobile.locator('#menu-btn').click();
await mobile.waitForTimeout(500);
const drawerOpen = await mobile.locator('#drawer').evaluate((el) => el.classList.contains('open'));
ok('移动端抽屉展开', drawerOpen);
// 点击抽屉外的遮罩区域关闭（抽屉占 86vw，左侧窄条为可点遮罩）
await mobile.mouse.click(16, 400);
await mobile.waitForTimeout(500);
const drawerClosed = await mobile.locator('#drawer').evaluate((el) => !el.classList.contains('open'));
ok('移动端抽屉点击遮罩关闭', drawerClosed);

// 移动端展开交互
const mToggle = mobile.locator('#articles-toggle');
await mToggle.click();
await mobile.waitForTimeout(900);
const mExtraItems = await mobile.locator('#articles-extra .extra-item').count();
ok('移动端展开 16 篇', mExtraItems === 16, `${mExtraItems} 条`);
const mNoHScroll = await mobile.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
ok('AC-15 移动端无横向滚动', mNoHScroll);
const mQrW = await mobile.locator('.footer-qr img').evaluate((el) => el.getBoundingClientRect().width);
ok('移动端二维码 80px', mQrW === 80, `${mQrW}px`);

await mobile.screenshot({ path: join(outDir, 'mobile-full.png'), fullPage: true });
await mobile.evaluate(() => window.scrollTo(0, 0));
await mobile.waitForTimeout(400);
await mobile.screenshot({ path: join(outDir, 'mobile-hero.png') });
ok('移动端无控制台报错', mErrors.length === 0, mErrors.slice(0, 3).join(' | '));
await mobile.close();

await browser.close();

const failed = results.filter((r) => !r.pass);
console.log(`\n===== 结果：${results.length - failed.length}/${results.length} 通过 =====`);
if (failed.length) {
  console.log('失败项：');
  failed.forEach((f) => console.log(`  - ${f.name}${f.detail ? ` (${f.detail})` : ''}`));
  process.exit(1);
}
