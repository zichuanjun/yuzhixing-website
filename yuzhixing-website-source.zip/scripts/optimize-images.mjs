/**
 * 图片优化脚本（design-spec §2.3 / AC-17）
 * - logo.png（230KB）→ logo.webp（主用）+ logo.png（压缩兜底），均 ≤60KB
 * - weixinerweima.jpg → weixin-qr.webp（主用）+ weixin-qr.jpg（兜底），均 ≤60KB
 * - 由源图生成 favicon（32px 方图）
 * 用法：node scripts/optimize-images.mjs
 * 源图位置：design/（工作区设计交付物），输出到 site/public/
 */
import sharp from 'sharp';
import { mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const srcDir = join(root, '..', 'design');
const outDir = join(root, 'public');
mkdirSync(outDir, { recursive: true });

const KB = 1024;

async function fitUnder(buf, budget, { width, quality }) {
  // 从给定参数开始，逐档降质量直至 ≤ budget
  let q = quality;
  let out = buf;
  while (q >= 55) {
    out = await sharp(buf).resize({ width }).webp({ quality: q }).toBuffer();
    if (out.length <= budget) return out;
    q -= 8;
  }
  // 质量已很低仍超预算 → 降分辨率
  for (const w of [Math.round(width * 0.8), Math.round(width * 0.6)]) {
    out = await sharp(buf).resize({ width: w }).webp({ quality: 72 }).toBuffer();
    if (out.length <= budget) return out;
  }
  throw new Error('无法压缩到预算内');
}

// ---------- Logo ----------
const logo = await sharp(join(srcDir, 'logo.png'));
const logoMeta = await logo.metadata();
console.log('logo 源图:', logoMeta.width + 'x' + logoMeta.height);

// WebP 主用
let logoWebp = await sharp(join(srcDir, 'logo.png')).webp({ quality: 82 }).toBuffer();
if (logoWebp.length > 60 * KB) {
  logoWebp = await fitUnder(join(srcDir, 'logo.png'), 60 * KB, { width: logoMeta.width, quality: 82 });
}
await sharp(logoWebp).toFile(join(outDir, 'logo.webp'));
console.log('logo.webp:', (logoWebp.length / KB).toFixed(1) + 'KB');

// PNG 压缩兜底（缩放 + palette）
let logoPng = await sharp(join(srcDir, 'logo.png'))
  .resize({ width: 512 })
  .png({ palette: true, quality: 90 })
  .toBuffer();
if (logoPng.length > 60 * KB) {
  logoPng = await sharp(join(srcDir, 'logo.png'))
    .resize({ width: 400 })
    .png({ palette: true, quality: 80 })
    .toBuffer();
}
await sharp(logoPng).toFile(join(outDir, 'logo.png'));
console.log('logo.png (兜底):', (logoPng.length / KB).toFixed(1) + 'KB');

// favicon：居中方形裁切 → 32px
const sq = Math.min(logoMeta.width, logoMeta.height);
await sharp(join(srcDir, 'logo.png'))
  .extract({
    left: Math.floor((logoMeta.width - sq) / 2),
    top: Math.floor((logoMeta.height - sq) / 2),
    width: sq,
    height: sq,
  })
  .resize(32, 32)
  .png()
  .toFile(join(outDir, 'favicon.png'));
console.log('favicon.png: 32x32');

// ---------- 公众号二维码 ----------
const qrBuf = await sharp(join(srcDir, 'weixinerweima.jpg'));
const qrMeta = await qrBuf.metadata();
console.log('二维码源图:', qrMeta.width + 'x' + qrMeta.height);

const qrWebp = await sharp(join(srcDir, 'weixinerweima.jpg'))
  .resize({ width: 384 }) // 96px@3x，覆盖高分屏
  .webp({ quality: 80 })
  .toBuffer();
await sharp(qrWebp).toFile(join(outDir, 'weixin-qr.webp'));
console.log('weixin-qr.webp:', (qrWebp.length / KB).toFixed(1) + 'KB');

const qrJpg = await sharp(join(srcDir, 'weixinerweima.jpg'))
  .resize({ width: 384 })
  .jpeg({ quality: 78 })
  .toBuffer();
await sharp(qrJpg).toFile(join(outDir, 'weixin-qr.jpg'));
console.log('weixin-qr.jpg (兜底):', (qrJpg.length / KB).toFixed(1) + 'KB');

console.log('done →', outDir);
