/** 外链资源连通性检查：识别哪些请求失败（如 Google Fonts 被墙） */
import { chromium } from 'playwright';
import { readdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';

const BASE = process.env.BASE_URL ?? 'http://localhost:4173';

function findChrome() {
  const root = join(homedir(), 'AppData', 'Local', 'ms-playwright');
  if (!existsSync(root)) return null;
  const dirs = readdirSync(root)
    .filter((d) => d.startsWith('chromium-'))
    .sort()
    .reverse();
  for (const d of dirs) {
    const p = join(root, d, 'chrome-win64', 'chrome.exe');
    if (existsSync(p)) return p;
  }
  return null;
}

const browser = await chromium.launch({ executablePath: findChrome() });
const page = await browser.newPage();
const failed = [];
page.on('requestfailed', (r) => failed.push({ url: r.url(), reason: r.failure()?.errorText }));
page.on('console', (m) => {
  if (m.type() === 'error') console.log('console-error:', m.text().slice(0, 160));
});
await page.goto(BASE, { waitUntil: 'load', timeout: 30000 });
await page.waitForTimeout(6000);
console.log('failed requests:', JSON.stringify(failed, null, 2));
const fontCheck = await page.evaluate(() => ({
  displayFont: getComputedStyle(document.querySelector('.hero h1')).fontFamily,
  fontsStatus: document.fonts.status,
}));
console.log('font check:', JSON.stringify(fontCheck));
await browser.close();
