/**
 * 设计令牌落地抽检：对照 design-spec v2.0 校验关键计算样式
 */
import { chromium } from 'playwright';
import { readdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';

const BASE = process.env.BASE_URL ?? 'http://localhost:4173';

function findChrome() {
  const root = join(homedir(), 'AppData', 'Local', 'ms-playwright');
  if (!existsSync(root)) return null;
  const dirs = readdirSync(root).filter((d) => d.startsWith('chromium-')).sort().reverse();
  for (const d of dirs) {
    const p = join(root, d, 'chrome-win64', 'chrome.exe');
    if (existsSync(p)) return p;
  }
  return null;
}

const browser = await chromium.launch({ executablePath: findChrome() });
// 强制深色（无头默认浅色系统偏好）
const ctx = await browser.newContext({ colorScheme: 'dark', viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
await page.goto(BASE, { waitUntil: 'networkidle' });
await page.waitForTimeout(800);

const checks = [];
const check = async (name, fn, expect) => {
  const v = await page.evaluate(fn);
  const pass = typeof expect === 'function' ? expect(v) : v === expect;
  checks.push({ name, pass, v, expect });
  console.log(`${pass ? 'PASS' : 'FAIL'}  ${name} = ${JSON.stringify(v)}${pass ? '' : ` (期望 ${JSON.stringify(expect)})`}`);
};

await check('深色 body 底色 #0d1b2a', () => getComputedStyle(document.body).backgroundColor, (v) => v === 'rgb(13, 27, 42)');
await check('H1 字号 clamp（1440 → 92px）', () => getComputedStyle(document.querySelector('.hero h1')).fontSize, (v) => parseFloat(v) >= 88 && parseFloat(v) <= 93);
await check('H1 字体 = 宋体族', () => getComputedStyle(document.querySelector('.hero h1')).fontFamily, (v) => v.includes('Noto Serif SC'));
await check('精选网格 3 列', () => getComputedStyle(document.getElementById('articles-grid')).gridTemplateColumns.split(' ').length, 3);
await check('区块 H2 字号', () => getComputedStyle(document.querySelector('.section-head h2')).fontSize, (v) => parseFloat(v) >= 40 && parseFloat(v) <= 55);
await check('卡片底色 --bg-panel', () => getComputedStyle(document.querySelector('.card')).backgroundColor, (v) => v === 'rgb(18, 36, 58)');
await check('卡片圆角 12px', () => getComputedStyle(document.querySelector('.card')).borderRadius, '12px');
await check('chip 圆角 999px', () => getComputedStyle(document.querySelector('.chip')).borderRadius, '999px');
await check('kicker 青色圆点', () => {
  const el = document.querySelector('.kicker');
  return getComputedStyle(el, '::before').backgroundColor;
}, (v) => v === 'rgb(0, 180, 216)');
await check('导航高 64px', () => document.querySelector('.header-inner').getBoundingClientRect().height, 64);
await check('容器最大宽 1160px', () => getComputedStyle(document.querySelector('.container')).maxWidth, '1160px');
await check('区块 padding 120px', () => getComputedStyle(document.querySelector('.section')).paddingTop, '120px');
await check('进度条渐变', () => getComputedStyle(document.getElementById('progress')).backgroundImage, (v) => v.includes('linear-gradient'));
await check('锚点 scroll-margin 88px', () => getComputedStyle(document.getElementById('articles')).scrollMarginTop, '88px');
await check('页脚深底 #071019', () => getComputedStyle(document.getElementById('site-footer')).backgroundColor, (v) => v === 'rgb(7, 16, 25)');

// 无 JS 降级：html.js 未挂载时内容可见（noscript 检查）
const noJsOk = await page.evaluate(() => document.documentElement.classList.contains('js'));
console.log(`${noJsOk ? 'PASS' : 'FAIL'}  html.js 已挂载（动效增强层生效）`);

const failed = checks.filter((c) => !c.pass);
console.log(`\n===== 样式抽检：${checks.length - failed.length}/${checks.length} 通过 =====`);
await browser.close();
if (failed.length) process.exit(1);
