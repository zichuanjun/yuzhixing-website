/**
 * 子路径部署冒烟测试（自包含）：
 * 将 dist/ 复制到临时目录的 /sub/ 下并起一个静态服务器，
 * 访问 /sub/index.html，校验相对路径构建在子路径托管下资源全部从 /sub/ 解析。
 */
import { chromium } from 'playwright';
import { cpSync, mkdtempSync, rmSync, readdirSync, existsSync, createReadStream } from 'node:fs';
import { createServer } from 'node:http';
import { join, dirname, extname } from 'node:path';
import { tmpdir, homedir } from 'node:os';
import { fileURLToPath } from 'node:url';

const distDir = join(dirname(fileURLToPath(import.meta.url)), '..', 'dist');

function findChrome() {
  const root = join(homedir(), 'AppData', 'Local', 'ms-playwright');
  if (!existsSync(root)) return null;
  const dirs = readdirSync(root)
    .filter((d) => d.startsWith('chromium-'))
    .sort()
    .reverse();
  for (const d of dirs) {
    const p = join(root, d, 'chrome-win64', 'chrome.exe');
    if (existsSync(p)) return p;
  }
  return null;
}

// 1. 布局：<tmp>/sub/ = dist 内容（子路径托管场景）
const tmp = mkdtempSync(join(tmpdir(), 'yx-subpath-'));
cpSync(distDir, join(tmp, 'sub'), { recursive: true });

// 2. 静态服务器（root = <tmp>）
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
};
const server = createServer((req, res) => {
  const path = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  const file = join(tmp, path === '/' ? '/index.html' : path);
  if (!file.startsWith(tmp) || !existsSync(file)) {
    res.writeHead(404);
    res.end();
    return;
  }
  res.writeHead(200, { 'Content-Type': MIME[extname(file)] ?? 'application/octet-stream' });
  createReadStream(file).pipe(res);
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const PORT = server.address().port;
const SUB_URL = `http://127.0.0.1:${PORT}/sub/index.html`;

const browser = await chromium.launch({ executablePath: findChrome() });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));
page.on('console', (m) => {
  if (m.type() === 'error') errors.push(m.text());
});

const resp = await page.goto(SUB_URL, { waitUntil: 'domcontentloaded', timeout: 30000 });
await page.waitForTimeout(1000);

const heroLogoResolved = await page.locator('.hero-logo').evaluate((el) => el.currentSrc);

// 二维码 lazy-load：滚动到底部触发加载后再读取解析地址
await page.locator('.footer-qr img').scrollIntoViewIfNeeded();
await page.waitForFunction(() => {
  const el = document.querySelector('.footer-qr img');
  return el && el.complete && el.currentSrc !== '';
}, { timeout: 10000 });

const result = {
  httpStatus: resp ? resp.status() : null,
  title: await page.title(),
  cards: await page.locator('.card').count(),
  heroLogoVisible: await page.locator('.hero-logo').isVisible(),
  heroLogoResolved,
  qrVisible: await page.locator('.footer-qr img').isVisible(),
  qrResolved: await page.locator('.footer-qr img').evaluate((el) => el.currentSrc),
  errors,
};
console.log(JSON.stringify(result, null, 2));

const subPrefix = `http://127.0.0.1:${PORT}/sub/`;
const assetsInSubpath =
  result.heroLogoResolved.startsWith(subPrefix) && result.qrResolved.startsWith(subPrefix);

await browser.close();
server.close();
rmSync(tmp, { recursive: true, force: true });

if (
  resp?.status() !== 200 ||
  result.cards !== 8 ||
  !result.heroLogoVisible ||
  !result.qrVisible ||
  !assetsInSubpath ||
  errors.length
) {
  process.exit(1);
}
console.log('PASS 子路径资源全部从 /sub/ 解析');
