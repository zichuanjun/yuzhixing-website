import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  // 相对路径：构建产物可部署到任意静态托管的根域名或子路径（如 GitHub Pages 项目页），无需改配置
  base: './',
})
