import { Reveal } from './Reveal';

/** 三支柱（PRD 3.3：桌面三列，移动端纵向堆叠） */
const PILLARS = [
  {
    num: '01',
    title: '做过 AI 产品',
    desc: '企业级 AI 产品从 0 到 1：检索增强、文档智能理解、复杂场景落地。',
  },
  {
    num: '02',
    title: '读过 MBA',
    desc: '西安交通大学 MBA · 战略管理。',
  },
  {
    num: '03',
    title: '写出来了',
    desc: '38 万字深度内容，6 篇行业方法论文章。',
  },
];

const STATS = [
  { num: '0 → 1', label: '企业级 AI 产品' },
  { num: 'MBA', label: '西安交大 · 战略管理' },
  { num: '38 万+', label: '字深度内容' },
  { num: '24 篇', label: '已发布文章' },
];

export function About() {
  return (
    <section className="section" id="about" aria-label="关于作者">
      <div className="container">
        <div className="section-head">
          <Reveal>
            <span className="kicker">01 — 关于作者 · ABOUT</span>
            <h2>做过 AI 产品，读过 MBA，写出来了。</h2>
          </Reveal>
        </div>

        <Reveal className="about-pillars">
          {PILLARS.map((p) => (
            <div key={p.num} className="pillar-card">
              <span className="pillar-num">{p.num}</span>
              <h3>{p.title}</h3>
              <p>{p.desc}</p>
            </div>
          ))}
        </Reveal>

        <Reveal delay={0.15}>
          <figure className="quote-panel centered">
            <blockquote>
              宇智行，AI 产品变革探索者。
              <br />
              做过 AI 产品，读过 MBA，写出来了。
              <br />
              帮你：找对场景 <span className="quote-x">×</span> AI 落地{' '}
              <span className="quote-x">×</span> 商业成果转化
            </blockquote>
            <figcaption>— 智行合一，数创未来</figcaption>
          </figure>
        </Reveal>

        <div className="stats">
          {STATS.map((s, i) => (
            <Reveal key={s.label} delay={i * 0.08} className="stat">
              <div className="num">{s.num}</div>
              <div className="label">{s.label}</div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
