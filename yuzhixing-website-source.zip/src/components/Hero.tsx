import type { CSSProperties } from 'react';
import { Logo } from './Logo';

const d = (v: string) => ({ '--d': v }) as CSSProperties;

export function Hero() {
  return (
    <section className="hero" id="hero" aria-label="品牌首屏">
      <div className="hero-grid" data-parallax="0.05" aria-hidden="true" />
      <div className="hero-glow-a" data-parallax="0.14" aria-hidden="true" />
      <div className="hero-glow-b" data-parallax="0.22" aria-hidden="true" />
      <p className="hero-side left" aria-hidden="true">
        YZX — AI × MBA × INSIGHT
      </p>
      <p className="hero-side right" aria-hidden="true">
        EST. 2026 · 智行合一
      </p>

      <div className="hero-content">
        <div className="intro-item" style={d('.05s')}>
          <Logo className="hero-logo logo-round" />
        </div>
        <p className="hero-kicker intro-item" style={d('.15s')}>
          AI 产品变革探索者
        </p>
        <h1 className="intro-item" style={d('.22s')}>
          <span className="h-line">
            <span className="h-line-in">智行合一</span>
          </span>
          <span className="h-line">
            <span className="h-line-in">数创未来</span>
          </span>
        </h1>
        <div className="hero-rule intro-item" style={d('.5s')} aria-hidden="true" />
        <p className="hero-sub intro-item" style={d('.58s')}>
          找对场景 <span className="x">×</span> AI 落地 <span className="x">×</span> 商业成果转化
        </p>
        <p className="hero-meta intro-item" style={d('.66s')}>
          <b>企业级 AI 从 0 到 1</b> · <b>西交大 MBA</b> · <b>38 万字深度内容</b>
        </p>
        <div className="hero-ctas intro-item" style={d('.74s')}>
          <a className="btn btn-primary magnetic" href="#articles">
            阅读方法论
          </a>
          <a className="btn btn-ghost" href="#philosophy">
            了解服务理念
          </a>
        </div>
      </div>

      <div className="scroll-hint intro-item" style={d('1s')} aria-hidden="true">
        <span className="wheel" />
        <span>Scroll</span>
      </div>
    </section>
  );
}
