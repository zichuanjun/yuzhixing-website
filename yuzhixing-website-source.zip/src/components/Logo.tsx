/**
 * 圆形 Logo（design-spec v2.0 §5）
 * 全站统一正圆呈现：等宽高 + border-radius:50% + object-fit:cover 居中裁切，
 * 尺寸由使用处的 CSS 控制（导航 32 / 抽屉 40 / Hero 56 / 页脚 36）。
 * WebP 主用 + 压缩 PNG 兜底，均 ≤60KB（AC-17）。
 */
export function Logo({
  className = 'logo-round',
  alt = '宇智行 Logo',
}: {
  className?: string;
  alt?: string;
}) {
  return (
    <picture>
      {/* 相对路径：保证子路径托管（如 GitHub Pages 项目页）下资源正常解析 */}
      <source srcSet="./logo.webp" type="image/webp" />
      <img className={className} src="./logo.png" alt={alt} loading="lazy" />
    </picture>
  );
}
