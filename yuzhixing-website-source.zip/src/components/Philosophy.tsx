import { Reveal } from './Reveal';

const PILLARS = [
  {
    title: ['不追热点，', '只讲逻辑'],
    desc: '热点会过期，逻辑不会。所有判断回到第一性原理与商业本质。',
    icon: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M15.5 8.5l-2 5-5 2 2-5z" />
      </>
    ),
  },
  {
    title: ['不炫概念，', '只说本质'],
    desc: '拆掉黑话的包装，把 AI 能力还原为可验证的业务价值。',
    icon: (
      <>
        <path d="M12 3l7 9-7 9-7-9z" />
        <path d="M5 12l7-9M12 12l7-9M5 12l7 9M12 12l7 9" />
      </>
    ),
  },
  {
    title: ['不造焦虑，', '只给洞察'],
    desc: '不用 FOMO 逼你决策，用结构与数据帮你看清下一步。',
    icon: (
      <>
        <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6z" />
        <circle cx="12" cy="12" r="3" />
      </>
    ),
  },
];

const STEPS = [
  {
    num: 'STEP 01',
    title: '找对场景',
    desc: '从业务瓶颈出发，筛选高价值 AI 场景，避开伪需求。',
    dir: '场景评估 → 需求优先级',
  },
  {
    num: 'STEP 02',
    title: 'AI 落地',
    desc: '从 0 到 1 交付可用产品：检索增强、文档智能、复杂场景工程化。',
    dir: '方案设计 → 工程交付',
  },
  {
    num: 'STEP 03',
    title: '商业成果转化',
    desc: '以商业成果为准绳，把技术投入翻译成可衡量的回报。',
    dir: '指标对齐 → 价值复盘',
  },
];

export function Philosophy() {
  return (
    <section className="section" id="philosophy" aria-label="服务理念">
      <div className="container">
        <div className="section-head center">
          <Reveal>
            <span className="kicker">03 — 服务理念 · PHILOSOPHY</span>
            <h2>三不原则</h2>
            <p className="lead">这是内容的标准，也是服务的方式。</p>
          </Reveal>
        </div>

        <Reveal className="pillar-grid">
          {PILLARS.map((p) => (
            <div key={p.title[1]} className="pillar">
              <span className="pillar-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24">{p.icon}</svg>
              </span>
              <h3>
                {p.title[0]}
                <em>{p.title[1]}</em>
              </h3>
              <p>{p.desc}</p>
            </div>
          ))}
        </Reveal>

        <Reveal className="steps">
          <p className="steps-title">HOW I HELP — 服务路径</p>
          <div className="steps-grid">
            {STEPS.map((s) => (
              <div key={s.num} className="step">
                <span className="step-num">{s.num}</span>
                <h4>{s.title}</h4>
                <p>{s.desc}</p>
                <p className="step-dir">{s.dir}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
