import { Logo } from './Logo';

const NAV_ITEMS = [
  { href: '#about', label: '关于作者' },
  { href: '#articles', label: '文章' },
  { href: '#philosophy', label: '服务理念' },
];

export function Footer() {
  return (
    <footer id="site-footer">
      <div className="container">
        <div className="footer-main">
          <div className="footer-brand">
            <a className="brand" href="#top" aria-label="宇智行 · 回到顶部">
              <Logo />
              <span className="brand-name">宇智行</span>
            </a>
            <p className="footer-slogan">智行合一，数创未来</p>
          </div>
          <div className="footer-cols">
            <div className="footer-col">
              <h5>导航</h5>
              {NAV_ITEMS.map((item) => (
                <a key={item.href} href={item.href}>
                  {item.label}
                </a>
              ))}
            </div>
            <div className="footer-col">
              <h5>关注</h5>
              <a href="#articles">公众号文章</a>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          {/* 页脚底部左侧：公众号关注二维码（项目经理规格 2026-08-30） */}
          <figure className="footer-qr">
            <picture>
              {/* 相对路径：保证子路径托管下资源正常解析 */}
              <source srcSet="./weixin-qr.webp" type="image/webp" />
              <img
                src="./weixin-qr.jpg"
                alt="关注宇智行公众号二维码"
                width={96}
                height={96}
                loading="lazy"
              />
            </picture>
            <figcaption>关注「宇智行」公众号</figcaption>
          </figure>
          <div className="footer-legal">
            <span>© {new Date().getFullYear()} 宇智行 · 保留所有权利</span>
            <span>京ICP备XXXXXXXX号（备案占位）</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
