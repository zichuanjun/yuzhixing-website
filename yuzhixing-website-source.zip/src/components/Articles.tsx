import { useState, type AnimationEvent, type CSSProperties } from 'react';
import articles from '../data/articles.json';
import { Reveal } from './Reveal';

export interface Article {
  title: string;
  link: string;
  category: string;
  featured: boolean;
}

/** 展开区四分类的固定顺序（PRD 3.4.2） */
const CATEGORY_ORDER = ['场景认知', '落地方法论', '商业成果', '个人实践'];

const featured = (articles as Article[]).filter((a) => a.featured);
const others = (articles as Article[]).filter((a) => !a.featured);
const total = (articles as Article[]).length;

function pad(n: number) {
  return n < 10 ? `0${n}` : String(n);
}

function Card({ article, index }: { article: Article; index: number }) {
  return (
    <a className="card" href={article.link} target="_blank" rel="noopener">
      <div className="card-head">
        <span className="card-index">{pad(index + 1)}</span>
        <span className="chip">{article.category}</span>
      </div>
      <h3>{article.title}</h3>
      <div className="card-foot">
        <span>阅读原文</span>
        <span className="arrow" aria-hidden="true">
          →
        </span>
      </div>
    </a>
  );
}

export function Articles() {
  const [expanded, setExpanded] = useState(false);

  /** 入场动画结束后移除 animation，恢复 hover 位移（fill 态会压制 transform） */
  const clearStagger = (e: AnimationEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    if (!target.classList.contains('extra-group')) return;
    target.style.animation = 'none';
  };

  return (
    <section className="section" id="articles" aria-label="文章列表">
      <div className="container">
        <div className="section-head">
          <Reveal>
            <span className="kicker">02 — 文章 · ESSAYS</span>
            <h2>深度内容</h2>
            <p className="lead">38 万字深度内容沉淀 · 24 篇文章</p>
          </Reveal>
        </div>

        <Reveal className="card-grid" id="articles-grid">
          {featured.map((a, i) => (
            <Card key={a.link} article={a} index={i} />
          ))}
        </Reveal>

        {/* 「查看全部」入口 */}
        <Reveal className="articles-toggle-row">
          <button
            className={`btn btn-ghost articles-toggle${expanded ? ' expanded' : ''}`}
            id="articles-toggle"
            aria-expanded={expanded}
            aria-controls="articles-extra"
            onClick={() => setExpanded(!expanded)}
          >
            <span className="toggle-label">{expanded ? '收起' : `查看全部 ${total} 篇`}</span>
            <span className="toggle-arrow" aria-hidden="true">
              ↓
            </span>
          </button>
        </Reveal>

        {/* 其余 16 篇：页内展开，按四分类分组（默认隐藏） */}
        <div className="articles-extra" id="articles-extra" hidden={!expanded}>
          <p className="extra-head">ALL {total} ESSAYS — 其余 {total - featured.length} 篇</p>
          <div className="extra-groups" onAnimationEnd={clearStagger}>
            {CATEGORY_ORDER.map((cat, gi) => {
              const items = others.filter((a) => a.category === cat);
              if (items.length === 0) return null;
              return (
                <div
                  key={cat}
                  className="extra-group"
                  style={{ '--i': gi } as CSSProperties}
                >
                  <p className="group-title">{cat}</p>
                  {items.map((a) => (
                    <a key={a.link} className="extra-item" href={a.link} target="_blank" rel="noopener">
                      <span className="t">{a.title}</span>
                      <span className="arrow" aria-hidden="true">
                        ↗
                      </span>
                    </a>
                  ))}
                </div>
              );
            })}
          </div>
          <div className="collapse-row">
            <button
              className="collapse-mini"
              id="articles-collapse-mini"
              aria-label="收起全部文章"
              onClick={() => setExpanded(false)}
            >
              收起全部 ↑
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
