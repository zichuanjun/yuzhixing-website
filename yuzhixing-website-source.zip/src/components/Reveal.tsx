import { useEffect, useRef, type CSSProperties, type ReactNode } from 'react';

const supportsScrollDriven =
  typeof window !== 'undefined' && 'CSS' in window && CSS.supports('animation-timeline', 'view()');

/**
 * 滚动揭示（interaction-plan P0-2）：
 * - 支持 scroll-driven animations 的浏览器由 CSS view() 时间线接管（零 JS、滚回自动反转）
 * - 兜底：IntersectionObserver 进入视口后加 .in
 * - prefers-reduced-motion 时由 CSS 全局关闭
 * 注意：含 hover 位移的交互元素（卡片/理念卡）应以“组”为单位包裹，避免
 * 动画 fill 态压制 hover transform。
 */
export function Reveal({
  children,
  delay,
  className,
  id,
}: {
  children: ReactNode;
  /** 同组 stagger 延迟（秒） */
  delay?: number;
  className?: string;
  id?: string;
}) {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (supportsScrollDriven) return;
    const el = ref.current;
    if (!el || !('IntersectionObserver' in window)) {
      el?.classList.add('in');
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add('in');
            io.unobserve(en.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -8% 0px' },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const style: CSSProperties | undefined = delay
    ? ({ '--d': `${delay}s` } as CSSProperties)
    : undefined;

  return (
    <div ref={ref} id={id} className={className ? `reveal ${className}` : 'reveal'} style={style}>
      {children}
    </div>
  );
}
