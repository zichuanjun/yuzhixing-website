import { useEffect, useState } from 'react';
import { Logo } from './Logo';

const NAV_ITEMS = [
  { href: '#about', label: '关于作者' },
  { href: '#articles', label: '文章' },
  { href: '#philosophy', label: '服务理念' },
];

export function Header({ onToggleTheme }: { onToggleTheme: () => void }) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const closeDrawer = () => setDrawerOpen(false);

  useEffect(() => {
    if (!drawerOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeDrawer();
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [drawerOpen]);

  return (
    <>
      <header id="site-header">
        <div className="container header-inner">
          <a className="brand" href="#top" aria-label="宇智行 · 回到顶部">
            <Logo />
            <span className="brand-name">宇智行</span>
          </a>
          <nav className="main-nav" aria-label="主导航">
            {NAV_ITEMS.map((item) => (
              <a key={item.href} href={item.href}>
                {item.label}
              </a>
            ))}
          </nav>
          <div className="header-actions">
            <button className="icon-btn" id="theme-toggle" aria-label="切换深浅主题" onClick={onToggleTheme}>
              <svg
                className="icon-sun"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                aria-hidden="true"
              >
                <circle cx="12" cy="12" r="4" />
                <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
              </svg>
              <svg
                className="icon-moon"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
              </svg>
            </button>
            <a className="btn btn-primary btn-sm header-cta" href="#articles">
              阅读方法论
            </a>
            <button
              className="menu-btn"
              id="menu-btn"
              aria-label={drawerOpen ? '关闭菜单' : '打开菜单'}
              aria-expanded={drawerOpen}
              aria-controls="drawer"
              onClick={() => setDrawerOpen(!drawerOpen)}
            >
              <span />
              <span />
            </button>
          </div>
        </div>
      </header>

      <div
        className={`drawer-backdrop${drawerOpen ? ' open' : ''}`}
        id="drawer-backdrop"
        onClick={closeDrawer}
      />
      <aside
        className={`drawer${drawerOpen ? ' open' : ''}`}
        id="drawer"
        aria-hidden={!drawerOpen}
      >
        <div className="drawer-head">
          <Logo />
          <span className="brand-name">宇智行</span>
        </div>
        <nav aria-label="移动端导航">
          {NAV_ITEMS.map((item) => (
            <a key={item.href} href={item.href} onClick={closeDrawer}>
              {item.label}
            </a>
          ))}
        </nav>
        <p className="drawer-meta">智行合一，数创未来</p>
      </aside>
    </>
  );
}
