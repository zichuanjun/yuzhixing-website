import { useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Articles } from './components/Articles';
import { Philosophy } from './components/Philosophy';
import { Footer } from './components/Footer';

const THEME_KEY = 'yx-theme';
const INTRO_KEY = 'yx-intro';

const reduced =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const canHover =
  typeof window !== 'undefined' &&
  window.matchMedia('(hover: hover) and (pointer: fine)').matches;
const supportsScrollDriven =
  typeof window !== 'undefined' && 'CSS' in window && CSS.supports('animation-timeline', 'scroll()');

export default function App() {
  /* ---------- 主题切换（P1-6） ---------- */
  const toggleTheme = useCallback(() => {
    const root = document.documentElement;
    const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    const apply = () => {
      root.classList.add('theme-anim');
      root.setAttribute('data-theme', next);
      try {
        localStorage.setItem(THEME_KEY, next);
      } catch {
        /* localStorage 不可用时仅本次会话生效 */
      }
      window.setTimeout(() => root.classList.remove('theme-anim'), 350);
    };
    const doc = document as Document & {
      startViewTransition?: (cb: () => void) => unknown;
    };
    if (typeof doc.startViewTransition === 'function' && !reduced) {
      doc.startViewTransition(apply);
    } else {
      apply();
    }
  }, []);

  /* 系统主题实时跟随：仅当用户未手动选择时生效 */
  useEffect(() => {
    let manual = false;
    try {
      manual = localStorage.getItem(THEME_KEY) !== null;
    } catch {
      /* ignore */
    }
    if (manual) return;
    const mq = window.matchMedia('(prefers-color-scheme: light)');
    const onChange = (e: MediaQueryListEvent) => {
      document.documentElement.setAttribute('data-theme', e.matches ? 'light' : 'dark');
    };
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  /* ---------- 开场动画（P0-1）：会话内只播一次，1s 超时兜底 ---------- */
  useEffect(() => {
    let played = false;
    const play = () => {
      if (played) return;
      played = true;
      document.documentElement.classList.add('is-loaded');
    };
    let manual = false;
    try {
      if (sessionStorage.getItem(INTRO_KEY) || reduced) {
        play();
        return;
      }
      sessionStorage.setItem(INTRO_KEY, '1');
      manual = true;
    } catch {
      play();
      return;
    }
    if (!manual) return;
    const t1 = window.setTimeout(play, 1000);
    if (document.fonts?.ready) {
      document.fonts.ready.then(() => window.setTimeout(play, 60));
    }
    return () => window.clearTimeout(t1);
  }, []);

  /* ---------- 导航 / 进度条 / 回到顶部 / 视差（P0-3 / P0-4 / P1-7） ---------- */
  useEffect(() => {
    const header = document.getElementById('site-header');
    const progress = document.getElementById('progress');
    const toTop = document.getElementById('to-top');
    if (!header || !progress || !toTop) return;

    const isDesktop = window.matchMedia('(min-width: 768px)').matches;
    let parallaxLayers: Array<{ el: HTMLElement; speed: number }> = [];
    if (canHover && isDesktop && !reduced) {
      parallaxLayers = Array.from(document.querySelectorAll<HTMLElement>('[data-parallax]')).map(
        (el) => ({ el, speed: parseFloat(el.dataset.parallax ?? '0.1') }),
      );
    }

    let ticking = false;
    let lastY = window.scrollY;

    const onScrollTick = () => {
      ticking = false;
      const y = window.scrollY;
      header.classList.toggle('scrolled', y > 8);
      if (isDesktop && !reduced) {
        if (y > lastY + 4 && y > 220) header.classList.add('hidden');
        else if (y < lastY - 4) header.classList.remove('hidden');
      }
      lastY = y;

      if (!supportsScrollDriven) {
        const max = document.documentElement.scrollHeight - window.innerHeight;
        progress.style.transform = `scaleX(${max > 0 ? Math.min(1, y / max) : 0})`;
      }
      toTop.classList.toggle('show', y > 600);

      if (parallaxLayers.length && y < window.innerHeight * 1.4) {
        parallaxLayers.forEach((l) => {
          l.el.style.transform = `translate3d(0,${(y * l.speed).toFixed(1)}px,0)`;
        });
      }
    };
    const onScroll = () => {
      if (!ticking) {
        requestAnimationFrame(onScrollTick);
        ticking = true;
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    /* 当前区块 → 导航高亮（scrollspy） */
    const navLinks = document.querySelectorAll<HTMLAnchorElement>('.main-nav a');
    const navIO = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (!en.isIntersecting) return;
          navLinks.forEach((a) => {
            a.classList.toggle('active', a.getAttribute('href') === `#${en.target.id}`);
          });
        });
      },
      { rootMargin: '-40% 0px -55% 0px' },
    );
    document.querySelectorAll('section[id]').forEach((s) => navIO.observe(s));

    const onToTop = () => window.scrollTo({ top: 0, behavior: reduced ? 'auto' : 'smooth' });
    toTop.addEventListener('click', onToTop);

    return () => {
      window.removeEventListener('scroll', onScroll);
      navIO.disconnect();
      toTop.removeEventListener('click', onToTop);
    };
  }, []);

  /* ---------- 微交互：卡片聚光灯 + 磁吸按钮（P1-5，仅 hover 指针设备） ---------- */
  useEffect(() => {
    if (!canHover || reduced) return;

    const onPointerMove = (e: PointerEvent) => {
      const target = e.target as HTMLElement;

      const card = target.closest<HTMLElement>('.card');
      if (card) {
        const r = card.getBoundingClientRect();
        card.style.setProperty('--mx', `${e.clientX - r.left}px`);
        card.style.setProperty('--my', `${e.clientY - r.top}px`);
      }

      const magnetic = target.closest<HTMLElement>('.magnetic');
      if (magnetic) {
        const r = magnetic.getBoundingClientRect();
        const dx = Math.max(-6, Math.min(6, (e.clientX - r.left - r.width / 2) * 0.18));
        const dy = Math.max(-6, Math.min(6, (e.clientY - r.top - r.height / 2) * 0.18));
        magnetic.style.transition = 'transform .1s ease-out';
        magnetic.style.transform = `translate(${dx.toFixed(1)}px,${dy.toFixed(1)}px)`;
      }
    };
    const onPointerLeave = (e: PointerEvent) => {
      const magnetic = (e.target as HTMLElement).closest<HTMLElement>('.magnetic');
      if (magnetic) {
        magnetic.style.transition = 'transform .3s cubic-bezier(.22,.61,.36,1)';
        magnetic.style.transform = '';
      }
    };

    document.addEventListener('pointermove', onPointerMove, { passive: true });
    document.addEventListener('pointerout', onPointerLeave, { passive: true });
    return () => {
      document.removeEventListener('pointermove', onPointerMove);
      document.removeEventListener('pointerout', onPointerLeave);
    };
  }, []);

  return (
    <>
      <a className="skip-link" href="#about">
        跳到主要内容
      </a>
      <div className="progress" id="progress" role="presentation" />
      <Header onToggleTheme={toggleTheme} />
      <main>
        <Hero />
        <About />
        <Articles />
        <Philosophy />
      </main>
      <Footer />
      <button className="to-top" id="to-top" aria-label="回到顶部">
        ↑
      </button>
    </>
  );
}
